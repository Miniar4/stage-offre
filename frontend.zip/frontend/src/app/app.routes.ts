
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core'; 
import { HomePageComponent } from './pages/home-page/home-page.component';
import { ContactPageComponent } from './pages/contact-page/contact-page.component';
import { CreateAccountPageComponent } from './pages/create-account-page/create-account-page.component';
import { SignInPageComponent } from './pages/sign-in-page/sign-in-page.component';
import { ApplyPageComponent } from './pages/apply-page/apply-page.component';
import { FormulaireOffreComponent } from './pages/formulaire-offre/formulaire-offre.component';
import { UserDashboardComponent } from './pages/user-dashboard/user-dashboard.component';
import { UserAttestationComponent } from './pages/user-attestation/user-attestation.component';
import { UserRapportComponent } from './pages/user-rapport/user-rapport.component';
import { AdminOffreComponent } from './pages/admin-account/admin-offre/admin-offre.component';
import { AdminContactComponent } from './pages/admin-account/admin-contact/admin-contact.component';
import { AdminCandidateComponent } from './pages/admin-account/admin-candidate/admin-candidate.component';
import { AdminDashboardComponent } from './pages/admin-account/admin-dashboard/admin-dashboard.component';
import { AdminAddStagiaireComponent } from './pages/admin-account/stagiaire-add/stagiaire-add.component';
import { AdminGuard } from './guards/admin.guard';
import { AuthGuard} from './guards/auth.guard';
import { PhysicalAlertComponent } from './pages/physical-alert/physical-alert.component';

export const routes: Routes = [
  { path: '', component: HomePageComponent },
  { path: 'contact', component: ContactPageComponent },
  { path: 'create-account', component: CreateAccountPageComponent },
  { path: 'sign-in', component: SignInPageComponent },
  { path: 'apply', component: ApplyPageComponent },
  { path: 'formulaire-offre/:id', component: FormulaireOffreComponent },
  { path: 'profile', component: UserDashboardComponent, canActivate: [AuthGuard] },
  { path: 'attestation', component: UserAttestationComponent },
  { path: 'rapport', component: UserRapportComponent },
  { path: 'admin/offres', component: AdminOffreComponent },
  { path: 'admin/contacts', component: AdminContactComponent },
 { path: 'admin/candidatures', component: AdminCandidateComponent },
  { path: 'contact', component: ContactPageComponent },
  { path: 'admin', component: AdminDashboardComponent, canActivate: [AdminGuard] },
  { path: 'admin/stagiaire-add/:candidatureId', component: AdminAddStagiaireComponent },
  {path:'hse',component: PhysicalAlertComponent}

];
 @NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {} 


