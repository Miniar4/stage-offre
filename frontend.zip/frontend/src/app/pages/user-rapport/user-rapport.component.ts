// cSpell:disable

import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-user-rapport',
  imports: [CommonModule],
  standalone:true,
  templateUrl: './user-rapport.component.html',
  styleUrls: ['./user-rapport.component.css']
})
export class UserRapportComponent {
  selectedFile: File | null = null;
  message = '';
  userId: number = 0;

  constructor(private http: HttpClient) {
    const user = localStorage.getItem('user');
    this.userId = user ? JSON.parse(user).id : 0;
  }

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  upload() {
    if (!this.selectedFile) {
      this.message = "Aucun fichier sélectionné";
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post(`http://localhost:5000/api/rapport/${this.userId}/upload`, formData).subscribe({
      next: () => this.message = 'Rapport envoyé avec succès',
      error: () => this.message = 'Erreur lors de l’envoi'
    });
  }

  download() {
    this.http.get(`http://localhost:5000/api/rapport/${this.userId}/download`, { responseType: 'blob' }).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'rapport.pdf';
      a.click();
    });
  }
}
