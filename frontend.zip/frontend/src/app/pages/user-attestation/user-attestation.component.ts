// cSpell:disable

import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone:true,
  imports:[CommonModule,FormsModule],
  selector: 'app-user-attestation',
  templateUrl: './user-attestation.component.html',
  styleUrls: ['./user-attestation.component.css']
})
export class UserAttestationComponent {
  userId: number = 0;

  constructor(private http: HttpClient) {
    const user = localStorage.getItem('user');
    this.userId = user ? JSON.parse(user).id : 0;
  }

  telechargerAttestation() {
    this.http.get(`http://localhost:5000/api/user/${this.userId}/attestation`, { responseType: 'blob' }).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'attestation.pdf';
      a.click();
    });
  }
}
