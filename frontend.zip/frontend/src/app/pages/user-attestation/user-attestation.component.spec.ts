import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserAttestationComponent } from './user-attestation.component';

describe('UserAttestationComponent', () => {
  let component: UserAttestationComponent;
  let fixture: ComponentFixture<UserAttestationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserAttestationComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserAttestationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
