// cSpell:disable

import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../src/app/services/user.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router'; 

@Component({
  standalone:true,
  imports:[CommonModule,FormsModule],
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css']
})
export class UserDashboardComponent implements OnInit {
  userId: number = 0;
  candidatures: any[] = [];

  constructor(private userService: UserService,private router: Router) {}

  ngOnInit(): void {
    const user = localStorage.getItem('user');
    this.userId = user ? JSON.parse(user).id : 0;

    this.userService.getCandidatures(this.userId).subscribe((res) => {
      this.candidatures = res;
    });
  }
  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  } 
}
