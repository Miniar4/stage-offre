import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone:true,
  imports:[CommonModule,FormsModule] ,
  selector: 'app-sign-in-page',
  templateUrl: './sign-in-page.component.html',
  styleUrls: ['./sign-in-page.component.css']
})
export class SignInPageComponent {
  form = {
    email: '',
    password: ''
  };
  errorMsg = '';

  constructor(private authService: AuthService, private router: Router) {}

  login() {
    this.errorMsg = '';
    this.authService.login(this.form).subscribe({
      next: (res) => {
        this.authService.saveToken(res.access_token);
        this.authService.saveUser(res.user);
        const role = res.user.role;
        if (role === 'admin') {
          this.router.navigate(['/admin']);
        } else {
          this.router.navigate(['/profile']);
        }
      },
      error: (err) => {
        this.errorMsg = err.error?.error || 'Login failed';
      }
    });
  }
}
