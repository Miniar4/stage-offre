import { Component } from '@angular/core';
import { ContactService } from '../../services/contact.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@Component({
  standalone:true,
  imports:[CommonModule,FormsModule],
  selector: 'app-contact-page',
  templateUrl: './contact-page.component.html',
  styleUrls: ['./contact-page.component.css']
})
export class ContactPageComponent {
  // Données du formulaire
  form = {
    name: '',
    email: '',
    message: ''
  };

  constructor(
    private contactService: ContactService,
    private router: Router
  ) {}

  // Méthode appelée lors de l'envoi du formulaire
  envoyer() {
    if (this.form.name && this.form.email && this.form.message) {
      this.contactService.envoyerMessage(this.form).subscribe({
        next: () => {
          alert('Message envoyé avec succès !');
          this.router.navigate(['/']); // redirection vers la page principale
        },
        error: (err) => {
          console.error('Erreur lors de l\'envoi :', err);
          alert('Erreur lors de l\'envoi du message.');
        }
      });
    } else {
      alert('Merci de remplir tous les champs.');
    }
  }
}
