import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  selector: 'app-formulaire-offre',
  templateUrl: './formulaire-offre.component.html',
  styleUrls: ['./formulaire-offre.component.css']
})
export class FormulaireOffreComponent {
  offerId!: number;
  form = {
    name: '',
    email: '',
    university: '',
    education: '',
    duration: '',
    motivation: '',
    cv: null as File | null,
    motivationLetter: null as File | null
  };

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {
    this.offerId = +this.route.snapshot.paramMap.get('id')!;
  }

  onFileChange(event: any, type: 'cv' | 'motivationLetter') {
    if (event.target.files.length > 0) {
      this.form[type] = event.target.files[0];
    }
  }

  submit() {
    // Vérification des champs
    if (!this.form.cv || !this.form.motivationLetter || !this.form.motivation || !this.form.name || !this.form.email || !this.form.university || !this.form.education || !this.form.duration) {
      alert('Please complete all fields.');
      return;
    }

    const formData = new FormData();
    formData.append('name', this.form.name);
    formData.append('email', this.form.email);
    formData.append('university', this.form.university);
    formData.append('education', this.form.education);
    formData.append('duration', this.form.duration);
    formData.append('motivation', this.form.motivation);
    formData.append('cv', this.form.cv);
    formData.append('motivationLetter', this.form.motivationLetter);

    this.http.post(`http://localhost:5000/apply-offer/${this.offerId}`, formData)
      .subscribe({
        next: () => {
          alert('Application submitted successfully!');
          this.router.navigate(['/apply']);
        },
        error: (err) => {
          console.error('Submission error', err);
          alert('Submission failed.');
        }
      });
  }
}
