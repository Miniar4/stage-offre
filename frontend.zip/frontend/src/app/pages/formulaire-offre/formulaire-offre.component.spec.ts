// cSpell:disable

import { Component, OnInit } from '@angular/core';
import { OfferService } from 'src/app/services/offer.service';

@Component({
  selector: 'app-admin-offre',
  templateUrl: './admin-offre.component.html',
  styleUrls: ['./admin-offre.component.css']
})
export class AdminOffreComponent implements OnInit {
  offres: any[] = [];
  newOffre = { titre: '', description: '' };
  editMode = false;
  selectedOffreId: number | null = null;

  constructor(private offerService: OfferService) {}

  ngOnInit(): void {
    this.loadOffres();
  }

  loadOffres() {
    this.offerService.getAllOffers().subscribe((res) => {
      this.offres = res;
    });
  }

  ajouter() {
    this.offerService.createOffer(this.newOffre).subscribe(() => {
      this.loadOffres();
      this.newOffre = { titre: '', description: '' };
    });
  }

  modifier(offre: any) {
    this.newOffre = { titre: offre.titre, description: offre.description };
    this.selectedOffreId = offre.id;
    this.editMode = true;
  }

  enregistrerModif() {
    if (this.selectedOffreId !== null) {
      this.offerService.updateOffer(this.selectedOffreId, this.newOffre).subscribe(() => {
        this.loadOffres();
        this.annuler();
      });
    }
  }

  supprimer(id: number) {
    this.offerService.deleteOffer(id).subscribe(() => this.loadOffres());
  }

  annuler() {
    this.editMode = false;
    this.selectedOffreId = null;
    this.newOffre = { titre: '', description: '' };
  }
}
