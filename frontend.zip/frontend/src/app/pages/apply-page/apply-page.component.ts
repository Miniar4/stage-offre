import { Component, OnInit, OnDestroy } from '@angular/core';
import { OfferService } from '../../services/offer.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Subscription, interval } from 'rxjs';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  selector: 'app-apply-page',
  templateUrl: './apply-page.component.html',
  styleUrls: ['./apply-page.component.css']
})
export class ApplyPageComponent implements OnInit, OnDestroy {
  offers: any[] = [];
  loading = false;
  error = '';
  private subscription?: Subscription;

  constructor(private offerService: OfferService, private router: Router) {}

  ngOnInit(): void {
    this.loadOffers();
    // Recharger les données toutes les 30 secondes
  
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  loadOffers(): void {
    this.loading = true;
    this.error = '';
    
    this.offerService.getAllOffers().subscribe({
      next: (res) => {
        console.log('Réponse API:', res);
        
        if (Array.isArray(res)) {
          this.offers = res;
        } else {
          console.error('Réponse non attendue:', res);
          this.offers = [];
          this.error = 'Format de réponse invalide';
        }
        this.loading = false;
      },
      error: (err) => {
        console.error('Erreur de chargement des offres:', err);
        this.offers = [];
        this.error = 'Impossible de charger les offres';
        this.loading = false;
      }
    });
  }

  apply(offerId: number): void {
    this.router.navigate(['/formulaire-offre', offerId]);
  }

  refresh(): void {
    this.loadOffers();
  }
  trackByOfferId(index: number, offer: any): any {
    return offer.id; // Assuming your offer objects have an 'id' property
  }

}