import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone:true,
  imports:[CommonModule,FormsModule],
  selector: 'app-create-account-page',
  templateUrl: './create-account-page.component.html',
  styleUrls: ['./create-account-page.component.css']
})
export class CreateAccountPageComponent {
  form = {
    nom: '',
    email: '',
    password: '',
    role: 'stagiaire'  // ou 'admin' manuellement si nécessaire
  };
  successMsg = '';
  errorMsg = '';

  constructor(private authService: AuthService, private router: Router) {}

  register() {
    this.successMsg = '';
    this.errorMsg = '';
    this.authService.register(this.form).subscribe({
      next: (res) => {
        this.successMsg = res.message;
        this.router.navigate(['/login']);
      },
      error: (err) => {
        this.errorMsg = err.error?.error || 'Registration failed';
      }
    });
  }
}
