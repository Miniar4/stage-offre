import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAddStagiaireComponent } from './stagiaire-add.component';

describe('AdminAddStagiaireComponent', () => {
  let component: AdminAddStagiaireComponent;
  let fixture: ComponentFixture<AdminAddStagiaireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminAddStagiaireComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminAddStagiaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
