import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  selector: 'app-stagiaire-add',
  templateUrl: './stagiaire-add.component.html',
  styleUrls: ['./stagiaire-add.component.css']
})
export class AdminAddStagiaireComponent implements OnInit {
  candidatureId!: number;
  stagiaireId: number | null = null;

  // Formulaire
  form = {
    encadrant: '',
    sujet: ''
  };

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.candidatureId = +this.route.snapshot.paramMap.get('candidatureId')!;
    this.loadStagiaire();
  }

  loadStagiaire() {
    // Récupérer le stagiaire lié à la candidature si existe
    this.http.get<any>(`http://localhost:5000/admin/stagiaire/${this.candidatureId}`).subscribe({
      next: (data) => {
        if (data) {
          this.stagiaireId = data.id;
          this.form.encadrant = data.encadrant || '';
          this.form.sujet = data.sujet || '';
        }
      },
      error: (err) => {
        console.warn('Aucun stagiaire trouvé pour cette candidature', err);
        // On peut considérer que le stagiaire n'existe pas encore, donc on crée un nouveau
      }
    });
  }

  submit() {
    if (!this.form.encadrant || !this.form.sujet) {
      alert('Merci de remplir tous les champs.');
      return;
    }

    const payload = {
      application_id: this.candidatureId,
      encadrant: this.form.encadrant,
      sujet: this.form.sujet
    };

    if (this.stagiaireId) {
      // Modifier stagiaire existant
      this.http.put(`http://localhost:5000/admin/stagiaire/${this.stagiaireId}`, payload).subscribe({
        next: () => {
          alert('Stagiaire mis à jour avec succès');
          this.router.navigate(['/admin/stagiaires']);
        },
        error: (err) => {
          console.error(err);
          alert('Erreur lors de la mise à jour');
        }
      });
    } else {
      // Créer nouveau stagiaire
      this.http.post(`http://localhost:5000/admin/stagiaire`, payload).subscribe({
        next: () => {
          alert('Stagiaire ajouté avec succès');
          this.router.navigate(['/admin/stagiaires']);
        },
        error: (err) => {
          console.error(err);
          alert('Erreur lors de l\'ajout');
        }
      });
    }
  }
}