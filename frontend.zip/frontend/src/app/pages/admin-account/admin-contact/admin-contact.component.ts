import { Component, OnInit } from '@angular/core';
import { ContactService } from '../../../services/contact.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
   standalone: true,
  imports: [CommonModule,FormsModule],
  selector: 'app-admin-contact',
  templateUrl: './admin-contact.component.html',
  styleUrls: ['./admin-contact.component.css']
})
export class AdminContactComponent implements OnInit {
  contacts: any[] = [];

  constructor(private contactService: ContactService) {}

  ngOnInit(): void {
    this.contactService.getContacts().subscribe({
      next: (data: any) => {
        this.contacts = Array.isArray(data) ? data : [];
      },
      error: (err) => {
        console.error('Failed to load contacts:', err);
        this.contacts = [];
      }
    });
  }
}
