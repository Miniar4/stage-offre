import { Component, OnInit } from '@angular/core';
import { OfferService } from '../../../services/offer.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule],
  selector: 'app-admin-offer',
  templateUrl: './admin-offre.component.html',
  styleUrls: ['./admin-offre.component.css']
})
export class AdminOffreComponent implements OnInit {
  offers: any[] = [];
  newOffer = {
    title: '',
    description: '',
    desired_number: 1,
    skills: '',
    duration: '',
    start_date: '',
    end_date: ''
  };
  editMode = false;
  selectedOfferId: number | null = null;
  errorMessage = '';

  constructor(private offerService: OfferService) {}

  ngOnInit(): void {
    this.loadOffers();
  }

  loadOffers() {
    this.offerService.getAllOffers().subscribe({
      next: (res) => {
        if (!Array.isArray(res)) {
          this.errorMessage = 'Unexpected server response.';
          return;
        }
        this.offers = res;
        this.errorMessage = '';
      },
      error: (err) => {
        this.errorMessage = 'Failed to load offers.';
        console.error('API error:', err);
      }
    });
  }


  edit(offer: any) {
    this.newOffer = {
      title: offer.titre,
      description: offer.description,
      desired_number: offer.nb_souhaitee,
      skills: offer.competences,
      duration: offer.duree,
      start_date: offer.date_debut,
      end_date: offer.date_fin
    };
    this.selectedOfferId = offer.id;
    this.editMode = true;
  }

  saveChanges() {
    if (this.selectedOfferId === null) return;

    const offerPayload = {
      titre: this.newOffer.title,
      description: this.newOffer.description,
      nb_souhaitee: this.newOffer.desired_number,
      competences: this.newOffer.skills,
      duree: this.newOffer.duration,
      date_debut: this.newOffer.start_date,
      date_fin: this.newOffer.end_date
    };

    this.offerService.updateOffer(this.selectedOfferId, offerPayload).subscribe({
      next: () => {
        this.loadOffers();
        this.cancel();
      },
      error: (err) => {
        this.errorMessage = 'Failed to update the offer.';
        console.error('Update error:', err);
      }
    });
  }

  delete(id: number) {
    if (!confirm('Are you sure you want to delete this offer?')) return;

    this.offerService.deleteOffer(id).subscribe({
      next: () => this.loadOffers(),
      error: (err) => {
        this.errorMessage = 'Failed to delete the offer.';
        console.error('Delete error:', err);
      }
    });
  }

  cancel() {
    this.editMode = false;
    this.selectedOfferId = null;
    this.resetForm();
  }

  resetForm() {
    this.newOffer = {
      title: '',
      description: '',
      desired_number: 1,
      skills: '',
      duration: '',
      start_date: '',
      end_date: ''
    };
    this.errorMessage = '';
  }
   add() {
  const offerPayload = {
    titre: this.newOffer.title,
    description: this.newOffer.description,
    nb_souhaitee: this.newOffer.desired_number,
    competences: this.newOffer.skills,
    duree: this.newOffer.duration,
    date_debut: this.newOffer.start_date,
    date_fin: this.newOffer.end_date
  };

  this.offerService.createOffer(offerPayload).subscribe({
    next: () => {
      this.loadOffers();
      this.resetForm();
    },
    error: (err) => {
      this.errorMessage = 'Failed to create the offer.';
      console.error('Create error:', err);
    }
  });
}

}
