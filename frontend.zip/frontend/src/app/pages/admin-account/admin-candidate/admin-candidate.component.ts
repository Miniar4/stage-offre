import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  standalone:true,
  imports:[CommonModule,FormsModule],
  selector: 'app-admin-candidatures',
  templateUrl: './admin-candidate.component.html',
  styleUrls: ['./admin-candidate.component.css']
})
export class AdminCandidateComponent implements OnInit {
  applications: any[] = [];

 constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.loadApplications();
  }

  loadApplications() {
    this.http.get<any[]>('http://localhost:5000/admin/candidatures').subscribe({
      next: (res) => this.applications = res,
      error: (err) => console.error(err)
    });
  }

  download(type: 'cv' | 'motivation', filename: string) {
  const urlType = type === 'cv' ? 'admin/download/cv' : 'admin/download/motivation';
  window.open(`http://localhost:5000/${urlType}/${filename}`, '_blank');
}


 accept(app: any) {
  const body = { statut: 'accepté' };

  this.http.put(`http://localhost:5000/admin/candidature/${app.id}/statut`, body).subscribe({
    next: () => {
      alert('Candidature acceptée');
      // Redirection vers formulaire d'ajout stagiaire avec id candidature
      this.router.navigate(['/admin/stagiaire-add', app.id]);
    },
    error: (err) => {
      console.error(err);
      alert('Erreur lors de l\'acceptation');
    }
  });
}


reject(app: any) {
  this.http.put(`http://localhost:5000/admin/candidature/${app.id}/statut`, { statut: 'refusé' }).subscribe({
    next: () => {
      alert(`Application de ${app.name} refusée.`);
      this.loadApplications();
    },
    error: (err) => {
      console.error(err);
      alert('Erreur lors de la mise à jour.');
    }
  });
}


}
