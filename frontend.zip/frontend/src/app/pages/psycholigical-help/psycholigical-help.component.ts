import { Component } from '@angular/core';

@Component({
  selector: 'app-psycholigical-help',
  imports: [],
  templateUrl: './psycholigical-help.component.html',
  styleUrl: './psycholigical-help.component.css'
})
export class PsycholigicalHelpComponent {

}
