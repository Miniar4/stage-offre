import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PsycholigicalHelpComponent } from './psycholigical-help.component';

describe('PsycholigicalHelpComponent', () => {
  let component: PsycholigicalHelpComponent;
  let fixture: ComponentFixture<PsycholigicalHelpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PsycholigicalHelpComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PsycholigicalHelpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
