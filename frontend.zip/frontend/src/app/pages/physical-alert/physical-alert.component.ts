import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-physical-alert',
  imports: [CommonModule,FormsModule],
  templateUrl: './physical-alert.component.html',
  styleUrl: './physical-alert.component.css'
})
export class PhysicalAlertComponent {

  quizPassed = false;

  answers = {
    q1: '',
    q2: '',
    q3: ''
  };

  submitQuiz() {
    const correct = this.answers.q1 === 'ppe'
                 && this.answers.q2 === 'alert'
                 && this.answers.q3 === 'yes';

    if (correct) {
      this.quizPassed = true;
    } else {
      alert('❌ Some answers are incorrect. Please try again.');
    }
  }
}


