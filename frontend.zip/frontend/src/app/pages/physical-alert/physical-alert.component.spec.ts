import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PhysicalAlertComponent } from './physical-alert.component';

describe('PhysicalAlertComponent', () => {
  let component: PhysicalAlertComponent;
  let fixture: ComponentFixture<PhysicalAlertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PhysicalAlertComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PhysicalAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
