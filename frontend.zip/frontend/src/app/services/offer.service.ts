import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class OfferService {
  private baseUrl = 'http://localhost:5000';

  constructor(private http: HttpClient) {}

  getAllOffers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/offres`, {
      headers: { 'Cache-Control': 'no-cache' }
    }).pipe(
      retry(1),
      catchError(this.handleError)
    );
  }

  createOffer(offre: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/offres`, offre).pipe(
      catchError(this.handleError)
    );
  }

  updateOffer(id: number, offre: any): Observable<any> {
    return this.http.put(`${this.baseUrl}/offres/${id}`, offre).pipe(
      catchError(this.handleError)
    );
  }

  deleteOffer(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/offres/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  postulerOffre(userId: number, offerId: number): Observable<any> {
    return this.http.post(`${this.baseUrl}/candidature`, {
      user_id: userId,
      offer_id: offerId,
    }).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.error('Error in OfferService:', error);
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Client error: ${error.error.message}`;
    } else {
      errorMessage = `Server error: ${error.status} ${error.message}`;
    }
    
    return throwError(() => new Error(errorMessage));
  }
}