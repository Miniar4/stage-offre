import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private baseUrl = 'http://localhost:5000';

  constructor(private http: HttpClient) {}

  register(user: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, user);
  }

  login(credentials: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/login`, credentials);
  }

  // ✅ Méthode requise par JwtInterceptor
  getToken(): string | null {
  return localStorage.getItem('token');
}

saveToken(token: string): void {
  localStorage.setItem('token', token);
}

saveUser(user: any): void {
  localStorage.setItem('user', JSON.stringify(user));
}

getUser(): any {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}

isLoggedIn(): boolean {
  return !!this.getToken();
}

isAdmin(): boolean {
  const user = this.getUser();
  return user?.role === 'admin';
}

logout(): void {
  localStorage.clear();
}

}
