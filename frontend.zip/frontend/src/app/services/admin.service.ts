import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Stagiaire {
  id?: number;
  application_id: number;
  encadrant: string;
  sujet: string;
}         
@Injectable({ providedIn: 'root' })
export class AdminService {
  private baseUrl = 'http://localhost:5000';

  constructor(private http: HttpClient) {}

  getUsers(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/comptes`).pipe(
      catchError(this.handleError)
    );
  }

  getCandidatures(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/candidatures`).pipe(
      catchError(this.handleError)



    );
  }

  updateStatut(
    id: number,
    body: { statut: string; date_entretien?: string; lieu_entretien?: string }
  ): Observable<any> {
    return this.http.put(`${this.baseUrl}/admin/candidature/${id}/statut`, body).pipe(
      catchError(this.handleError)
    );
  }

  downloadCV(filename: string): void {
    window.open(`${this.baseUrl}/admin/download/cv/${filename}`, '_blank');
  }

  downloadMotivation(filename: string): void {
    window.open(`${this.baseUrl}/admin/download/motivation/${filename}`, '_blank');
  }

  getStagiaires(): Observable<any> {
    return this.http.get(`${this.baseUrl}/admin/stagiaires`).pipe(
      catchError(this.handleError)
    );
  }

  createStagiaire(stagiaire: Stagiaire): Observable<any> {
    return this.http.post(`${this.baseUrl}/admin/stagiaire`, stagiaire).pipe(
      catchError(this.handleError)
    );
  }

  updateStagiaire(id: number, stagiaire: Stagiaire): Observable<any> {
    return this.http.put(`${this.baseUrl}/admin/stagiaire/${id}`, stagiaire).pipe(
      catchError(this.handleError)
    );
  }

  deleteStagiaire(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/admin/stagiaire/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  commenterRapport(userId: number, data: { commentaire: string }): Observable<any> {
    return this.http.post(`${this.baseUrl}/admin/rapport/${userId}/commentaire`, data).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    console.error('Error in AdminService:', error);
    let errorMessage = 'An error occurred';
    
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Client error: ${error.error.message}`;
    } else {
      errorMessage = `Server error: ${error.status} ${error.message}`;
    }
    
    return throwError(() => new Error(errorMessage));
  }
  uploadAttestation(userId: number, file: File) {
    const formData = new FormData();
    formData.append('attestation', file);

    return this.http.post(`${this.baseUrl}/users/${userId}/attestation`, formData);
  }
}

