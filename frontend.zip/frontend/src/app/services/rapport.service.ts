import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class RapportService {
  private baseUrl = 'http://localhost:5000/rapport';

  constructor(private http: HttpClient) {}

  uploadRapport(userId: number, file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(`${this.baseUrl}/${userId}/upload`, formData);
  }

  downloadRapport(userId: number): void {
    const url = `${this.baseUrl}/${userId}/download`;
    window.open(url, '_blank');
  }
}
